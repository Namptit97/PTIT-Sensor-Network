import pymysql
import json

def Sensor(jsonData):
	
	json_Dict = json.loads(jsonData)
	print(json_Dict)
	SensorID = json_Dict['Sensor_ID']
	Temperature = json_Dict['Temperature']
	Humidity = json_Dict['Humidity']
	Date_and_Time = json_Dict['Date']
	# Open database connection
	db = pymysql.connect("localhost","wsn","Tieuch@u1902","wsn" )
	#prepare a cursor object using cursor() method
	cursor = db.cursor()
	# Execute the SQL command
	# Prepare SQL query to INSERT a record into the database.
	sql = """INSERT INTO sensors (SensorID,Temperature,Humidity,Date_and_Time) 
			 VALUES (%s,%s,%s,%s)"""
	val = (SensorID,Temperature,Humidity,Date_and_Time)
	cursor.execute(sql,val)
	db.commit()
	print ("Sensor created new value")
	print("-------------------------")

	# disconnect from server
	db.close()