import pymysql
import json

def in_(jsonData):
	json_Dict = json.loads(jsonData)
	SensorID = json_Dict['Sensor_ID']
	Temperature = json_Dict['Temperature']
	Humidity = json_Dict['Humidity']
	Date_and_Time = json_Dict['Date']
	print(SensorID,Temperature,Humidity,Date_and_Time)
	#Mo ket noi database
	db.pymysql.connect("locahost", "wsn", "Tieuch@u1902", "wsn")
	cursor = db.cursor()
	sql = """INSERT INTO sensors (SensorID, Temperature, Humidity, Date_and_Time)
				VALUES (%s, %s, %s, %s)
		"""
	val = (SensorID, Temperature, Humidity, Date_and_Time)
	cursor.execute(sql, val)
	db.commit()
	print("Sensor created new value")
	print("----------------------------------")
	db.close()